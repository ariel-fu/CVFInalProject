function change(){
	document.getElementById("change").innerHTML = 'Doggos are the best!';
	
}